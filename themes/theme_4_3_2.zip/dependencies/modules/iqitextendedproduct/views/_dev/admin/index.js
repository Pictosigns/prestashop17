import './admin_tab.js';
import './admin_tab.scss';
