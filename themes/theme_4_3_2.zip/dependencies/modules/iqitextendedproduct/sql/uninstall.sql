DROP TABLE PREFIXiqit_threesixty;
DROP TABLE PREFIXiqit_productvideo;

